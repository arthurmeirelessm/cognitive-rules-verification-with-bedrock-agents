import asyncio
from quart import Quart
from src.routes.run_test_routes import RunTestRoutes

app = Quart(__name__)

run_test_routes = RunTestRoutes()
app.register_blueprint(run_test_routes.run_test_blueprint)

if __name__ == "__main__":
    asyncio.run(app.run(debug=True))
